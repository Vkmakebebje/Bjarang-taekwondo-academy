BAJRANG TAEKWONDO ACADEMY WEBSITE: HOW TO EDIT

PAGES (each is a separate file, open in any text editor)
  index.html     Home
  about.html     About, Taekwondo, tenets, class structure
  programs.html  Kids, teens, adults, skills, timings and fees note
  belts.html     Belt journey
  gallery.html   Photo grid, lightbox and slideshow
  results.html   Achievements
  faq.html       Questions and answers (copy a <details> block to add one)
  contact.html   Contact details and WhatsApp message form
  css/style.css  Colors, layout, animations (colors are at the top: --orange, --green)
  js/script.js   Slider, 3D tilt, menu, lightbox, contact form
  images/        Logo, photos, Instagram QR code

COMMON EDITS
  Phone number   search "919391823020" and "93918 23020" in every .html and in js/script.js
  Instagram      search "bajrang_taekwondo_academy" in every .html
  Add a photo    put it in images/, then copy a <figure> block in gallery.html and index.html
  Fees/timings   add them in programs.html (search "Batch timings and fees")

PUBLISH
  Upload the whole folder (all pages, css, js, images) to Netlify Drop, GitHub Pages or Cloudflare Pages.
