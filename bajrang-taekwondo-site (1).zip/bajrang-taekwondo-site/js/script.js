const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.15});
$$('.rv').forEach(el=>io.observe(el));
if(!reduce){
$$('[data-tilt]').forEach(el=>{const m=+el.dataset.tilt||10,t=el.classList.contains('tilt')?el:$('.tilt',el);
el.addEventListener('pointermove',e=>{const r=el.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;t.style.setProperty('--ry',x*m+'deg');t.style.setProperty('--rx',-y*m+'deg')});
el.addEventListener('pointerleave',()=>{t.style.setProperty('--ry','0deg');t.style.setProperty('--rx','0deg')})});
const hero=$('.hero');if(hero)hero.addEventListener('pointermove',e=>{const r=hero.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;$$('[data-depth]',hero).forEach(l=>{const d=+l.dataset.depth;l.style.transform=`translate3d(${x*d}px,${y*d}px,0)`})});
}
if($('#stage')){
const slides=$$('.slide'),dots=$('#dots'),n=slides.length;let cur=0,timer;
slides.forEach((_,i)=>{const b=document.createElement('button');b.setAttribute('aria-label','Go to slide '+(i+1));b.onclick=()=>go(i);dots.appendChild(b)});
function show(){slides.forEach((s,i)=>{let o=i-cur;if(o>n/2)o-=n;if(o<-n/2)o+=n;const a=Math.abs(o);
s.style.transform=`translateX(calc(-50% + ${o*62}%)) rotateY(${-o*36}deg) scale(${a?.78:1})`;
s.style.opacity=a>1?0:(a?.55:1);s.style.zIndex=10-a;s.style.pointerEvents=a?'none':'auto';s.setAttribute('aria-hidden',a?'true':'false')});
$$('button',dots).forEach((b,i)=>b.setAttribute('aria-current',i===cur))}
function go(i){cur=(i+n)%n;show();play()}
function play(){clearInterval(timer);if(!reduce)timer=setInterval(()=>{cur=(cur+1)%n;show()},4500)}
$('#prev').onclick=()=>go(cur-1);$('#next').onclick=()=>go(cur+1);
let sx=null;const st=$('#stage');st.addEventListener('pointerdown',e=>sx=e.clientX);
st.addEventListener('pointerup',e=>{if(sx!==null&&Math.abs(e.clientX-sx)>40)go(cur+(e.clientX<sx?1:-1));sx=null});
show();play();
}

/* ===== MOBILE MENU ===== */
const mb=$('.menu'),nav=$('#nav');
mb.onclick=()=>{const o=nav.classList.toggle('open');mb.setAttribute('aria-expanded',o)};
$$('#nav a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');mb.setAttribute('aria-expanded','false')}));

/* ===== KICK IMPACT: tap or click anywhere ===== */
if(!reduce){
const words=['KIHAP!','HAI!','YAH!'];
document.addEventListener('pointerdown',e=>{
const r=document.createElement('span');r.className='burst';r.style.left=e.clientX+'px';r.style.top=e.clientY+'px';document.body.appendChild(r);
const els=[r];
if(Math.random()<.4){const w=document.createElement('span');w.className='kw';w.textContent=words[Math.floor(Math.random()*words.length)];w.style.left=e.clientX+'px';w.style.top=e.clientY+'px';document.body.appendChild(w);els.push(w)}
setTimeout(()=>els.forEach(x=>x.remove()),800)})}


/* ===== PHOTO LIGHTBOX (gallery page) ===== */
const lb=document.createElement('div');lb.className='lb';lb.hidden=true;lb.innerHTML='<img alt=""><button aria-label="Close photo">×</button>';document.body.appendChild(lb);
$$('.gal figure').forEach(f=>{f.tabIndex=0;const open=()=>{const i=$('img',lb),s=$('img',f);i.src=s.src;i.alt=s.alt;lb.hidden=false};f.addEventListener('click',open);f.addEventListener('keydown',e=>{if(e.key==='Enter')open()})});
lb.onclick=()=>lb.hidden=true;addEventListener('keydown',e=>{if(e.key==='Escape')lb.hidden=true});

/* ===== CONTACT FORM: opens WhatsApp with your message ===== */
const wf=$('#wform');
if(wf)wf.addEventListener('submit',e=>{e.preventDefault();const f=new FormData(wf);
const t='Hello Bajrang Taekwondo Academy! I am '+f.get('name')+'. Interested in: '+f.get('group')+'. '+(f.get('msg')||'');
window.open('https://wa.me/919391823020?text='+encodeURIComponent(t),'_blank','noopener')});
